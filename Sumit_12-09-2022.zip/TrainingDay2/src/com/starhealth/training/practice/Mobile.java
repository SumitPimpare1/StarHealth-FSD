package com.starhealth.training.practice;

public class Mobile extends Object {
	static String name;
	static int ram; // Instance variable are Now static.
	static double size;
	static int price;

	public Mobile(String name, int ram, double size, int price) {

		this.name = name;
		this.ram = ram;
		this.size = size;
		this.price = price;

	}

	public Mobile() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}
