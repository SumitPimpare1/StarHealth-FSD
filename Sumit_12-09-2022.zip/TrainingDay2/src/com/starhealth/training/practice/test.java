package com.starhealth.training.practice;

public class test {

	public static void main(String[] args) {
		Mobile m1 = new Mobile("Samsung", 6, 5.0, 2000);

		Mobile m2 = new Mobile("Onplus", 6, 4.5, 30000);

		Mobile m4 = new Mobile();

		m4.setName("Apple");

		System.out.println("Mobile parameters are prited here");

		System.out.println(m1.getName() + " " + m1.getRam() + "  " + m1.getSize() + " " + m1.getPrice());

		System.out.println(m2.getName() + " " + m2.getRam() + "  " + m2.getSize() + " " + m1.getPrice());
		System.out.println(m4.getName() + " " + m4.getRam() + "  " + m4.getSize() + " " + m4.getPrice());

	}

}
