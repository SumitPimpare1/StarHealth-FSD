package com.starhealth.training.prctice1;

public class Typecasting {

	public static void main(String[] args) {
		int a = 10;

		byte b = (byte) a;
		System.out.println(b); // Explicit Typecasting (Narrowing)

		int num = 5;
		long Num = (long) num;
		System.out.println(Num); // Implicit Typecasting(Widening)
	}

	public String method() {

		return "Data from the Typecasting class";
	}

}
