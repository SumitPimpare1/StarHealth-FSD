package com.starhealth.training.prctice1;

public class VariablePractice {
	int price = 300;
	String fruit = "mango"; // price and fruit are Global instance variables
							// global variables are default values.

	public static void main(String[] args) {
		int price = 150; // Local variable must be declared,bcz it doesn't contain any default value
		String fruit = "apple";
		VariablePractice f1 = new VariablePractice();
		VariablePractice a1 = new VariablePractice();
		a1.diplay();

		Typecasting t1 = new Typecasting();
		String b = t1.method();
		System.out.println(b);

		System.out.println("you have to pay " + price + " rupees for 1kg " + fruit);
		System.out.println("you have to pay " + f1.price + " rupees for 1kg " + f1.fruit);
		// System.out.println(fruit + " ");
	}

	public void diplay() {
		System.out.println("Fruits are available");
	}

}
