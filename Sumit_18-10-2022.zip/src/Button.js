import './App.css';

function Button(props) {
  return (
    <h1 className=' App App-link'>{props.bname}</h1>
    
  );
}
export default Button;

// var Button=(props)=>{
//     return(
//  < div className='App'><button>{props.bname}</button><br></br></div>
//       );
// }
// export default Button;