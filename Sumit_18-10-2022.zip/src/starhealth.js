import React, { Component } from 'react'

export default class starhealth extends Component {
  render() {
    return (
      <div>starhealth</div>
    )
  }
}
