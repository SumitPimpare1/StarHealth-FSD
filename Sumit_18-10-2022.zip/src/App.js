import logo from './logo.svg';
import './App.css';
import Button from './Button.js'


function App(props) {
  return (
    <div>
    <h1 className=' App App-link'>Its react app {props.title}</h1>
    
    </div>
  );
}

export default App;
