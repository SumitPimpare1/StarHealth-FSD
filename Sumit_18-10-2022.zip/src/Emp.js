
import {Component } from 'react';
class Emp extends Component{

    render(props){
        return <div className='App'><h4>This is Emp component{this.props.name}</h4></div>
    }
}
export default Emp;