import React, { Component } from 'react'

export default class Customer extends Component {


  render(){
    return (
      <div>Customer</div>
    )
  }
}
