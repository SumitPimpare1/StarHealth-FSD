import React from 'react'

export default function star(props) {
  return (
    <div className='App'>its new functional componet {props.name}</div>
  )
}
