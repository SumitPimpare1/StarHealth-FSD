package com.bank.info;

public class test2 {
	public void run() {
		System.out.println("test two");
	}

}
