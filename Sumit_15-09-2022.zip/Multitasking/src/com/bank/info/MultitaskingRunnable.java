package com.bank.info;

public class MultitaskingRunnable implements Runnable {

	public static void main(String[] args) {
		Thread t1 = new Thread(new MultitaskingRunnable());
//		Thread t2 =new Thread(new TestMultitasking2());  
//		  
		t1.start();
//		t2.start();  

	}

	@Override
	public void run() {
		System.out.println("Testing ");

	}

}
