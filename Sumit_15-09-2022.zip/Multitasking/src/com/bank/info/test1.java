package com.bank.info;

public class test1 {
	public void run() {
		System.out.println("test one");
	}

}
