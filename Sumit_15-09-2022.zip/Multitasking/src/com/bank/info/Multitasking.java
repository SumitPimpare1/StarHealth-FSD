package com.bank.info;

public class Multitasking extends Thread {

	public static void main(String[] args) {
		Multitasking task = new Multitasking();
		Multitasking task1 = new Multitasking();

		task1.start();
		task.start();

	}

}
