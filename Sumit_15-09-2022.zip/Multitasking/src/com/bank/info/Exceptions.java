package com.bank.info;

import java.util.Scanner;

public class Exceptions {
	public static void main(String[] args) {

		try {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter your ATM Pin : ");
			String pin = sc.next();
			if (pin.equals("1234")) {
				System.out.println("Successfull!.. You withdrawal cash");
			} else {
				System.out.println("please enter Corect Pin. Thank you");
			}

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("please enter Corect Pin. Thank you");
		} finally {
			System.out.println("thanksss");
		}

	}

}
