export class Student{

    RollNo:number =0;
    sname:string = "";
    age:number = 0;
    
}