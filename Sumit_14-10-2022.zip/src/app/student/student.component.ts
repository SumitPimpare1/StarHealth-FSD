import { Component, OnInit } from '@angular/core';
import { Student } from './student';
import { StudentService } from './student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  std:Student=new Student()
  
  stdList:Student[] =[];

  constructor(private service:StudentService) { }

  ngOnInit(): void {
  }
  insertFormData(data:Student){

    console.log("data from form "+data)
    this.service.insert(data);
  }

    
    getAllStudent(){
    
      this.service.getAll().subscribe((std: Student[]) => {this.stdList = std;console.log(this.stdList)});
  }

  
}



// function getAllStudent() {
//   throw new Error('Function not implemented.');
// }

