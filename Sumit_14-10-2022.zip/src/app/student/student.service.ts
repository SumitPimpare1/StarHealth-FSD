import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Student } from './student';
import { Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  constructor(private http:HttpClient) { }

  url:string = "http://localhost:3000/Std"

  getAll():Observable<Student[]>{

   return  this.http.get<Student[]>(this.url);  // return Observables

  }
  insert(stdObj:Student){

    console.log(stdObj)
    return  this.http.post<Student>(this.url,stdObj).subscribe( (data:Student) => {console.log('data from post '+data)});


  }

  
}
// function getAll() {
//   throw new Error('Function not implemented.');
// }

