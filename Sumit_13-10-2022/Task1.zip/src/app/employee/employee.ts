export interface Employee{

    Name:string;
    Contact :number;
    Email:string;
}

// eid:number;
//     ename:string;
//     salary:number;