import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  
  emp:Employee={"Name":"","Contact":0,"Email":""}

  constructor() { }

  ngOnInit(): void {
  }
  getFormData(data:Employee){
  
  }

}
