package com.Java8;

import java.util.ArrayList;
import java.util.List;

public class demo {

	public static void main(String[] args) {
		IntDemo m = (int a, int b) -> {
			return a + b;
		};
		int res = m.add(4, 9);
		System.out.println(res);

		List<Integer> numbers = new ArrayList<Integer>();
		numbers.add(10);
		numbers.add(7);
		numbers.add(4);
		numbers.add(2);
		numbers.forEach((n) -> {
			System.out.println(n);
		});
	}

}
