package com.Java8;

@FunctionalInterface
public interface IntDemo {

	public abstract int add(int a, int b);

	// void m(String a);

}
