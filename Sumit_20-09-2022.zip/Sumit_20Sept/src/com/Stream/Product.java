package com.Stream;

public class Product {
	String name;
	int id;
	float price;

	public Product(int id, String name, float price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}

}
