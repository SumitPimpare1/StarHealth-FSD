package com.training.springbootrestapidemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.springbootrestapidemo.entity.Employee;
import com.training.springbootrestapidemo.repository.IEmployeeRepo;

@Service
public class EmployeeServiceImplementation implements IEmployeeService {

	@Autowired
	IEmployeeRepo repo;
	
	
	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return repo.save(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return repo.save(emp);
	}

	@Override
	public Employee selectById(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).orElse(new Employee());
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

	@Override
	public List<Employee> selectAllEmployees() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
