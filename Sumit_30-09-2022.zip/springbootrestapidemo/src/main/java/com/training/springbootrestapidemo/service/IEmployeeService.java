package com.training.springbootrestapidemo.service;

import java.util.List;

import com.training.springbootrestapidemo.entity.Employee;

public interface IEmployeeService {
	
	public Employee addEmployee(Employee emp);
	public Employee updateEmployee(Employee emp);
	public Employee selectById(int id);
	public void deleteById(int id);
	public List<Employee> selectAllEmployees();
}
