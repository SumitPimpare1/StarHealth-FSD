package com.training.springbootrestapidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootrestapidemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
