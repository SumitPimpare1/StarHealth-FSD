
public class Test2 {

	public void run() {
		System.out.println("test one 2");
	}

}
