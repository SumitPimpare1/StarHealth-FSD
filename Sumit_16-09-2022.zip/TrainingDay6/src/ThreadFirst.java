
public class ThreadFirst extends Thread {

	public static void main(String[] args) {
		ThreadSecond obj = new ThreadSecond();

		obj.start();

		synchronized (obj) {

			try {

				System.out.println("Wait Thread 2 to complete...");

				obj.wait();
			}

			catch (InterruptedException e) {

				e.printStackTrace();
			}

			System.out.println("Total is: " + obj.Sum);
		}
	}

}
