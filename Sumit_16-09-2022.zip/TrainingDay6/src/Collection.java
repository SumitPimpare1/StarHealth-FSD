
import java.util.LinkedList;
import java.util.List;

public class Collection {

	public static void main(String[] args) {

		List<Object> linkedlist = new LinkedList<>();
		linkedlist.add(12);
		linkedlist.add(122);
		linkedlist.add("pune");
		linkedlist.add(2, "Mumbai");

		System.out.println(linkedlist);
		System.out.println(linkedlist.get(2));
		System.out.println(linkedlist.lastIndexOf(1));

	}

}
