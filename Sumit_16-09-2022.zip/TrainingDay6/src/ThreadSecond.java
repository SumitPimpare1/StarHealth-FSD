
public class ThreadSecond extends Thread {

	int Sum;

	public void run() {

		synchronized (this) {

			for (int i = 0; i < 10; i++) {

				Sum += i;
			}

			notify();
		}

	}

}
