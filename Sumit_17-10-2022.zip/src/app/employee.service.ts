import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError} from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

   url:string = "http://localhost:8080/api/v1/employees";

  getAll():Observable<Employee[]>{
   
   return   this.http.get<Employee[]>(this.url+'/getall');  // all http methods return Observables
  
  }

  insert(empObj:Employee){

    console.log(empObj)
    return  this.http.post<Employee>(this.url+'/add',empObj).subscribe( (data:Employee) => {console.log('data from post '+data)});

  }

  deleteById(id:number):Observable<string>{

     return   this.http.delete<string>(this.url+'/delete/'+id);

  }

  update(updateObj:Employee){

   return   this.http.put<Employee>(this.url+'/update',updateObj).subscribe((data:Employee)=>console.log(data));

  }
  errorHandler(error: { error: { message: string; }; status: any; message: any; }) {
        let errorMessage = '';
        if(error.error instanceof ErrorEvent){
          errorMessage = error.error.message;
        } else {
          errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
     }
}




