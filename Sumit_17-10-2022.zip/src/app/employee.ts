export class Employee{

    id:number =0;
    ename:string = "";
    salary:number = 0;
    



}

