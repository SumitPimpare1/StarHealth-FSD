package com.springannotations.dao;

public interface IBookRepo {

    public void getRepo();
}
