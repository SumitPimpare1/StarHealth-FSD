package com.springannotations.beans;

public class Student {

}
