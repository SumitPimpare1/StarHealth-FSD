package com.springannotations.service;

public interface IBookService {

    public void callService();
}

