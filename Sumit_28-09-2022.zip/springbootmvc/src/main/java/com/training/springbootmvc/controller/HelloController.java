package com.training.springbootmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/api")
public class HelloController {
	
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	@ResponseBody
	public String hello() {
		return "hello friends";
	}
	
	@RequestMapping(value="/app",method=RequestMethod.GET)
	@ResponseBody
	public String application() {
		return "hello world application";
	}
	
	@RequestMapping(value="/app/next",method=RequestMethod.GET)
	@ResponseBody
	public String app_next() {
		return "hello world next level application";
	}

}
