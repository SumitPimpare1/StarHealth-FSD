package com.training.springboot1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.training.springboot1.beans.Car;
import com.training.springboot1.service.ICarService;
import com.training.springboot1.service.CarServiceImp;

@SpringBootApplication
public class Springboot1Application {
	
	@Bean("p1")
	public Car getProductObj() {
		return new Car();
	}

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(Springboot1Application.class, args);
		ICarService service = context.getBean(CarServiceImp.class);
		System.out.println(service);
		service.getCar();
	}

}
