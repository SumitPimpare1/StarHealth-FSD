package com.training.springboot1.service;

public interface ICarService {
	public void getCar();
}
