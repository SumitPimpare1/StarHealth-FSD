package com.training.springboot1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.springboot1.repo.ICarRepo;

@Service
public class CarServiceImp implements ICarService {

	@Autowired
	ICarRepo repo;
	
	@Override
	public void getCar() {
		// TODO Auto-generated method stub
		System.out.println("Product Service");
		System.out.println(repo);
		repo.getCar();
	}

}
