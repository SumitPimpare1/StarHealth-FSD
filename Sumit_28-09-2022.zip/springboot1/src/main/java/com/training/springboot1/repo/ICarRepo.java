package com.training.springboot1.repo;

public interface ICarRepo {
	
	public void getCar();

}
