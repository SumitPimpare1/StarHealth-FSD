package com.training.springboot1.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.training.springboot1.beans.Car;

@Repository
public class ICarRepoImp implements ICarRepo {

	@Autowired
	Car product;
	@Override
	public void getCar() {
		// TODO Auto-generated method stub
		System.out.println("Product Repository");
		System.out.println("Product:"+product);
	}

}
