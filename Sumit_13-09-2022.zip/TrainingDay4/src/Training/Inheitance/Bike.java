package Training.Inheitance;

public class Bike extends Vehicle {
	public static void main(String[] args) {

		Vehicle v = new Vehicle();
		v.Sound();
		System.out.println("parent to parent access to properties" + v.toString());

		Bike b = new Bike();
		b.display();
		b.Sound();

		System.out.println("called toString method only :  " + b);

	}

	public void display() {
		System.out.println("dispaly method inheritance by Vehicle Class");
	}

}
