package Training.Inheitance;

public class Vehicle {

	public Vehicle() {
		super();
		System.out.println("Vehicle constuctor is called");

	}

	public void Sound() {
		System.out.println("Sound method");
	}

	public void Transport() {
		System.out.println("Transport method");
	}

}
