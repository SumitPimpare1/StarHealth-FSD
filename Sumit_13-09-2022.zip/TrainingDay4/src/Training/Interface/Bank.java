package Training.Interface;

public interface Bank {

	public abstract void print();

	public abstract void deposite();

}
