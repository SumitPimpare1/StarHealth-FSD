package Training.Interface;

public abstract class Banker implements Bank {

	public void print() {
		System.out.println("print method by interface");
	}

}
