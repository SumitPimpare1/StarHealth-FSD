package Training.Interface;

public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Banker obj = new Banker() {

			@Override
			public void deposite() {

				System.out.println("depostie method");
			}
		};
		obj.deposite();
		obj.print();

	}

}
