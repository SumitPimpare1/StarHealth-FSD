package Training.abstraction;

public class Childclass {
	public void dogSound() {

		System.out.println("dog sound from Childclass");
	}

}
