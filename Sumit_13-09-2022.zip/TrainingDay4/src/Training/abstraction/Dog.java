package Training.abstraction;

public abstract class Dog {
	public abstract void DogSound();

	public void dogSound() {
		System.out.println("bowbow");
	}

}
