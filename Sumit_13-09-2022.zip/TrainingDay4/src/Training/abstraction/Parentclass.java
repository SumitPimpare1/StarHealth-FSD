package Training.abstraction;

public class Parentclass {

	public static void main(String[] args) {
		Childclass o = new Childclass();
//		o.DogSound();
		o.dogSound();
	}

}
