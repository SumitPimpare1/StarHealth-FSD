package Training.Polymorphism;

public class Animal {

	public void eat() {
		System.out.println("Eating");
	}

	public void display() {
		System.out.println("Annimals class print display() method");
	}

	public static void main(String[] args) {
		Animal a = new Animal();
		a.eat();
		Animal a1 = new dog();
		a1.eat();
	}

}
