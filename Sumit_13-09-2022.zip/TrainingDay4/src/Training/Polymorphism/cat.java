package Training.Polymorphism;

import Training.abstraction.Dog;

public class cat {
	public void eat() {
		System.out.println("eating rat");
	}

	public static void main(String[] args) {

//		overiding method
		Animal obj1 = new Dog();
		obj1.display();

		Animal obj2 = new Animal();
		obj2.display();
	}

}
