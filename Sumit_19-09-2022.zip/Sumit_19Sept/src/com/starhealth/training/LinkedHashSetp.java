package com.starhealth.training;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetp {

	public static void main(String[] args) {
		Set<Integer> yes = new LinkedHashSet<Integer>();

		yes.add(22);
		yes.add(30);
		yes.add(44);
		yes.add(80);
		yes.add(55);

		System.out.println(yes);

		Set<Product> yes1 = new LinkedHashSet<Product>();

		yes1.add(new Product(10, "Sumit", 2000));
		yes1.add(new Product(11, "rahu", 3000));
		yes1.add(new Product(10, "Chnchad", 2000));
		yes1.add(new Product(12, "Rastogi", 3000));
		yes1.add(new Product(13, "madhavan", 4000));

		System.out.println(yes1);

	}

}
