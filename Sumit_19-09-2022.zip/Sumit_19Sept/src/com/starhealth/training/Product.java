package com.starhealth.training;

import java.util.Objects;

public class Product {
	private int ProNumber;

	private String ProName;

	private int ProAmount;

	public Product() {

	}

	public Product(int proNumber, String proName, int proAmount) {
		super();
		ProNumber = proNumber;
		ProName = proName;
		ProAmount = proAmount;
	}

	public int getProNumber() {
		return ProNumber;
	}

	public void setProNumber(int proNumber) {
		ProNumber = proNumber;
	}

	public String getProName() {
		return ProName;
	}

	public void setProName(String proName) {
		ProName = proName;
	}

	public int getCusAmount() {
		return ProAmount;
	}

	public void setCusAmount(int proAmount) {
		ProAmount = proAmount;
	}

	@Override
	public String toString() {
		return "Product [ProNumber=" + ProNumber + ", ProName=" + ProName + ", CusAmount=" + ProAmount + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(ProNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return ProNumber == other.ProNumber;
	}

}
