package com.starhealth.training;

import java.util.HashSet;
import java.util.Set;

public class HashSetp {

	public static void main(String[] args) {
		Set<Product> ob1 = new HashSet<Product>();

		Set<Integer> ob2 = new HashSet<Integer>();

		ob2.add(55);
		ob2.add(44);
		ob2.add(35);
		ob2.add(25);
		ob2.add(10);

		System.out.println(ob2);

		ob1.add(new Product(1, "Sumit", 1000));
		ob1.add(new Product(2, "mahesh", 2000));
		ob1.add(new Product(3, "digvijay", 1000));
		ob1.add(new Product(1, "RAhul", 1000));

		System.out.println(ob1);

	}

}
