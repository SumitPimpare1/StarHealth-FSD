package com.starhealth.training;

import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class HashMap {

	public static void main(String[] args) {
		Map<Integer, String> o = new Hashtable<Integer, String>();

		o.put(1, "Sumit");
		o.put(3, "Pimpare");
		o.put(2, "Mahesh");
		o.put(3, "Divijay");
		o.put(4, "Rahul");

		System.out.println(o);

		System.out.println(o.values());
		System.out.println(o.keySet());
		System.out.println(o.get(3));

		Set<Integer> set1 = o.keySet();

		for (Integer key : set1) {

			System.out.println(key + " " + o.get(key));

		}

	}

}
