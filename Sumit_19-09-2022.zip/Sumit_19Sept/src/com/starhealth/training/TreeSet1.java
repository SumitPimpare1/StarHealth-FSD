package com.starhealth.training;

import java.util.Set;
import java.util.TreeSet;

public class TreeSet1 {

	public static void main(String[] args) {
		Set<Integer> ob = new TreeSet<Integer>();

		ob.add(11);
		ob.add(13);
		ob.add(15);
		ob.add(12);
		ob.add(14);

		System.out.println(ob);

		Set<Product> ob1 = new TreeSet<Product>(new MyComparator());

		ob1.add(new Product(1, "Sp", 2000));
		ob1.add(new Product(2, "DSP", 3000));
		ob1.add(new Product(4, "Dysp", 5000));
		ob1.add(new Product(3, "Commi", 1000));
		ob1.add(new Product(5, "ASP", 6000));

		System.out.println(ob1);

	}

}
