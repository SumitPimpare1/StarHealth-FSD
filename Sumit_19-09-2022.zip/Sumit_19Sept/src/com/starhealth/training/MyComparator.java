package com.starhealth.training;

import java.util.Comparator;

public class MyComparator implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
		String s1 = o1.toString();

		String s2 = o2.toString();
		return s1.compareTo(s2);
	}

}
