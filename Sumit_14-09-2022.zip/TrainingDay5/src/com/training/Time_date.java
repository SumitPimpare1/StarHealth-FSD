package com.training;

import java.time.LocalDate;
import java.time.LocalTime;

public class Time_date {

	public static void main(String[] args) {
		LocalDate date = LocalDate.now();

		System.out.println("now of date" + date);
		System.out.println("day of month" + date.getDayOfMonth());
		System.out.println("month value" + date.getMonthValue());
		System.out.println(date.plusYears(5));
		System.out.println(date.isLeapYear());

		LocalTime time = LocalTime.now();
		System.out.println(time);
		System.out.println(time.getHour());
		System.out.println(time.getNano());

		LocalTime timeof = LocalTime.of(23, 3, 18);
		System.out.println("time by user" + timeof);
		System.out.println("second ...." + timeof.getSecond());
		System.out.println("nano second .." + timeof.getNano());

	}

}
