package com.training;

public class Str_Stringbuffer {

	public static void main(String[] args) {
		String str1 = new String("Raman Sharma");
		String str2 = " from starhealth ";
		String str3 = " chennai ";

		System.out.println("string methods  are charAt  :  " + str1.charAt(1));
		System.out.println("string methods  are concat  : " + str1.concat(str2));
		System.out.println("string methods  are  lowercase :" + str1.toLowerCase());
		System.out.println("string methods  are length  : " + str1.length());
		System.out.println("string methods  are lastindex  :" + str1.lastIndexOf(0));
		System.out.println("string methods  are uppercase  :" + str1.toUpperCase());

		StringBuffer buffer = new StringBuffer("Star health  ");
		System.out.println("substring method" + buffer.substring(7, 9));
		System.out.println("replace string by index" + buffer.replace(2, 7, "good"));
		System.out.println("reverse method" + buffer.reverse());
		System.out.println("append method" + buffer.append("insurance"));
		System.out.println("delete method" + buffer.delete(7, 9));

	}

}
