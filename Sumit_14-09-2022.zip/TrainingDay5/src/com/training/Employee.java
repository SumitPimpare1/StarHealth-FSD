package com.training;

public class Employee {

	public static void main(String[] args) {
		Emp o = new Emp();
		o.setAddress(" Sector 62 , Noida Uttar Pradesh");
		o.setId(1);
		o.setName("raman Sharma");

		Emp o1 = new Emp("raman", 2, "pune");

		System.out.println(o);

		System.out.println("Hashcode( )" + o1.hashCode());
		System.out.println("equals method : " + o1.equals(o));
		System.out.println(o1 == o);

	}

}
