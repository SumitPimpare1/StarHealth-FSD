package com.example.springmicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeacherMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
