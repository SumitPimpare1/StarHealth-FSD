package Package1;

public class DataType {

	public static void main(String[] args) {

		int num = 45;
		short marks = 90;
		String stName = "Sumit";
		double score = 9.0;
		long rank = 2222222;
		float Marks = 5.05f;
		char letter = 'A';
		boolean value = true;

		System.out.println("Here is the all data Which is Coverde in 9th Sept");

		System.out.println(num);
		System.out.println(marks);
		System.out.println(score);
		System.out.println(rank);
		System.out.println(Marks);
		System.out.println(letter);
		System.out.println(value);
		System.out.println(stName);

	}

}
